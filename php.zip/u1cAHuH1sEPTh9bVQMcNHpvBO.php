<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Basic -->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Site Metas -->
     
    <title>Artigo</title>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <!-- Site CSS -->
    <link rel="stylesheet" href="style.css" />
    <!-- ALL VERSION CSS -->
    <link rel="stylesheet" href="css/versions.css" />
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css" />
  </head>
  <body class="host_version">
    <!-- LOADER -->
    <div id="preloader">
      <div class="loader-container">
        <div class="progress-br float shadow">
          <div class="progress__item"></div>
        </div>
      </div>
    </div>
    <!-- END LOADER -->

    <!-- Start header -->
    <header class="top-navbar">
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
          <a class="navbar-brand text-white" href="index.php"> Busca </a>
          <button
            class="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbars-host"
            aria-controls="navbars-rs-food"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbars-host">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index.php">Início</a>
              </li>
              <li class="nav-item active">
                <a class="nav-link" href="blog.php">Artigo</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="contact.php">Contactos</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="policy.php">Política de privacidade</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="terms.php">Termos e condições</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
    <!-- End header -->

    <div
      id="carouselExampleControls"
      class="carousel slide bs-slider box-slider"
      data-ride="carousel"
      data-pause="hover"
      data-interval="false"
    >
      <div class="carousel-inner" role="listbox">
        <div class="carousel-item active">
          <div
            id="home"
            class="first-section"
            style="background-image: url('./assets/images/alex-haney-xwkryosf8_c-unsplash.jpg')"
          >
            <div class="dtab">
              <div class="container">
                <div class="row">
                  <div class="col-md-12 col-sm-12 text-center">
                    <div class="big-tagline">
                      <h2><strong>Artigo</strong></h2>
                    </div>
                  </div>
                </div>
                <!-- end row -->
              </div>
              <!-- end container -->
            </div>
          </div>
          <!-- end section -->
        </div>
      </div>
    </div>

    <div id="overviews" class="section wb">
      <div class="container">
        <!-- end title -->
        <div class="row align-items-center">
          <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
            <div class="message-box">
              <h3>Resumindo o top 5 jogos de tabuleiro: 5 Grandes jogos de cerca de gladiadores</h3>
              <p><strong></strong> Não há muito tempo, escrevemos um artigo sobre 5 grandes jogos de tabuleiro cerca de gladiadores. Hoje vamos tentar novamente para repetir a tarefa. Os critérios para esta tarefa foram o tamanho dos jogos e o número de jogadores (jogadores). No artigo de hoje sobre o tema "5 Grandes Jogos de Tabuleiro sobre Gladiadores" mais uma vez convidamos você a comentar sobre os jogos que você já tenha jogado e que, na sua opinião, continuam a ser o melhor entre eles. Você também pode compartilhar a sua opinião sobre os jogos que você ainda não tentei.Atenção!!! Com este top, nós expressam a opinião do corpo editorial e não nos propusemos a tarefa de ofender alguém. Nós acabamos de dar a nossa opinião, que poderá ser diferente do seu! Você pode entrar em contato conosco em: opinions@kongregate.com. Vamos também entrar em contato com você se existem jogos que você gostou.Atenção!!! Com este top, nós expressamos a opinião do corpo editorial e não nos propusemos a tarefa de ofender alguém. Nós acabamos de dar a nossa opinião, que poderá ser diferente do seu! Você pode entrar em contato conosco em: opinions@kongregate.com. Vamos também entrar em contato com você se existem jogos que você gostou.Jogos que já jogou mais divertido do que jogos que você ainda não jogou ainda. Eles também são mais baratos do que não jogar qualquer jogos. Se você como ele depende de seus próprios gostos, mas você deve definitivamente tentar jogar alguns dos jogos que você ainda não tenha jogado.5. "Não é Apenas um Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Muito Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita, Bonita,</p>
            </div>
            <!-- end messagebox -->
          </div>
          <!-- end col -->
        </div>
        <!-- end row -->
      </div>
      <!-- end container -->
    </div>
    <!-- end section -->

    <!-- end footer -->

    <div class="copyrights">
      <div class="container">
        <div class="footer-distributed">
          <div class="footer-center">
            <p class="footer-company-name">
              ©
              <script>
                document.write(new Date().getFullYear());
              </script>
              Copyright
            </p>
          </div>
        </div>
      </div>
      <!-- end container -->
    </div>
    <!-- end copyrights -->

    <a href="#" id="scroll-to-top" class="dmtop global-radius"><i class="fa fa-angle-up"></i></a>

    <div class="cookie-banner">
      <p style="color: #000000">
        O site utiliza cookies. Eles permitem reconhecê-lo e de receber alertas com informação sobre a sua experiência do usuário.Continuando a ver o site, eu concordo com o uso de cookies, proprietário do site de acordo com 
        <a target="_blank" href="https://en.wikipedia.org/wiki/HTTP_cookie"
          >A política de cookies</a
        >
      </p>

      <button class="close-cookie">×</button>
    </div>

    <script>
      window.onload = function () {
        $('.close-cookie').click(function () {
          $('.cookie-banner').fadeOut();
        });
      };
    </script>

    <script>
      let elems = document.querySelectorAll('.server-name');
      elems.forEach((elem) => {
        elem.innerHTML = window.location.hostname;
      });
    </script>

    <!-- ALL JS FILES -->
    <script src="js/all.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/custom.js"></script>
  </body>
</html>
